"""Reproducible candidate-performance research."""
